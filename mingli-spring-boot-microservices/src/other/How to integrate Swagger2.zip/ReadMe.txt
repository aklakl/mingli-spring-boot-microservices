1.we should add the  swagger2 plugin in pom.xml.(PS: for support your project using swagger2 plugin)
		<!-- swagger2 plugin for automatic generated API documentation -->
		<dependency>
		    <groupId>io.springfox</groupId>
		    <artifactId>springfox-swagger2</artifactId>
		    <version>2.7.0</version>
		</dependency>
		
		<!-- swagger-ui for view the swagger's json file -->
		<dependency>
		    <groupId>io.springfox</groupId>
		    <artifactId>springfox-swagger-ui</artifactId>
		    <version>2.7.0</version>
		</dependency>
		
		<!-- Generating your own meta-data using the annotation processor -->
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-configuration-processor</artifactId>
			<optional>true</optional>
		</dependency>

2.copy the SwaggerConfig.java in your project. (PS:this is configuration for apply your project)
In this step, you should config this code ".apis(RequestHandlerSelectors.basePackage("com.robustwealth.microservices.rwholding.controller"))" in SwaggerConfig.java (PS:this path will be your project's controller package path)

3.config the following configuration in your application.yml  (PS: you should config the individual inclientId,clientSecret,accessTokenUri for SwaggerConfig.java )
security:
  oauth2:
    client:
      clientId: robustwealth
      clientSecret: rwsecret
      scope: webapp
      accessTokenUri: https://${stagenetwork.ipAddress}/v1/uaa/oauth/token
      userAuthorizationUri: https://${stagenetwork.ipAddress}/v1/uaa/oauth/authorize
    resource:
      userInfoUri: https://${stagenetwork.ipAddress}/v1/uaa/user

4.copy the CustomResouceServerConfig.java  in your project (PS:this is configuration for expose the swagger api-docs url,and swagger-ui.html without spring security authorization )

5.make this bean in your application.(Because this is support for integrate swagger API-DOCS URL in WIKI,If you don't want to integrate swagger API-DOCS URL in WIKI,you can skip this configuration)
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;    
import org.springframework.boot.web.servlet.FilterRegistrationBean;
    @Bean
    FilterRegistrationBean corsFilterRegistration(@Value("${tagit.origin:*}") String origin) {
        return new FilterRegistrationBean(new Filter() {
            public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
                    throws IOException, ServletException {
                HttpServletResponse response = (HttpServletResponse) res;
                //this origin value could just as easily have come from a database or from a request parameter
                response.setHeader("Access-Control-Allow-Origin", "*");//you can use origin parameter
                chain.doFilter(req, res);
            }
            
            public void init(FilterConfig filterConfig) {
            	//System.out.println("FilterRegistrationBean init ");
            }

            public void destroy() {
            	//System.out.println("FilterRegistrationBean destroy ");
            }
        });
    }


