package com.robustwealth.microservices.ads.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.*;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Configuration
@EnableSwagger2
@ConfigurationProperties
public class Swagger2Config {

    @Value("${security.oauth2.client.clientId}")
    private String clientId;
    @Value("${security.oauth2.client.clientSecret}")
    private String clientSecret;
    @Value("${security.oauth2.client.accessTokenUri}")
    private String accessTokenUri;
   
    
    
    public static final String securitySchemaOAuth2 = "oauth2";
    
	@Bean
    public Docket productApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.robustwealth.microservices.ads.controller"))
                .paths(PathSelectors.ant("/overview*/*"))
                .build()
                .securitySchemes(securitySchemes())
                .securityContexts(Arrays.asList(SecurityContext.builder().securityReferences(SecurityReferences()).build()))
                .pathMapping("/")
                .apiInfo(apiInfo());
    }
	
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("RobustWealth REST API documentation")
                .description("RobustWealth Spring Boot REST API")
                .version("1.0")
                .license("RobustWealth Licence Version 1.0")
                .licenseUrl("https://docs.advrw.com/TCPP.pdf")
                .contact(new Contact("RobustWealth", "https://www.robustwealth.com/", "service@robustwealth.com"))
                .build();
    }
    
    
    private List<SecurityScheme> securitySchemes() {
        ArrayList<SecurityScheme> authorizationTypes = new ArrayList<>();
        
        /* not sure why scopes are used for both authorization and authorization
         * type
         * API is not using the scopes for now
         */
        List<AuthorizationScope> authorizationScopeList = new ArrayList<>();
        //authorizationScopeList.add(new AuthorizationScope("read", "read only"));
        //authorizationScopeList.add(new AuthorizationScope("write", "read and write"));
        //authorizationScopeList.add(new AuthorizationScope(authorizationScopeGlobal, "webapp is our default authorization Scope "));
        
        List<GrantType> grantTypes = new ArrayList<>();
     	grantTypes.add(new ClientCredentialsGrant(accessTokenUri));
        /* OAuth authorization type with client credentials and password grant
         * types.
         */
        authorizationTypes.add(new OAuth(securitySchemaOAuth2, authorizationScopeList,grantTypes));
        return authorizationTypes;
    }
    
    private List<SecurityReference> SecurityReferences() {

        List<SecurityReference> authorizations = new ArrayList<SecurityReference>();
        /* use same scopes as above */
        AuthorizationScope[] authorizationScopes = {
        		/*new AuthorizationScope("read", "read only"),
        		new AuthorizationScope("write", "read and write"),
        		new AuthorizationScope(authorizationScopeGlobal, "webapp is our default authorization Scope ")*/};

        /* Currently we have 2 roles - user and client */
        authorizations.add(new SecurityReference(securitySchemaOAuth2, authorizationScopes));
        return authorizations;

    }

    
}
